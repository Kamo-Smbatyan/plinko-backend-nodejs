const dotenv = require('dotenv')

dotenv.config();

let WEBHOOK_ID = process.env.WEBHOOK_ID || null ;

function setWebHookID(value){
    WEBHOOK_ID = value
}

function getWebHookID(){
    return WEBHOOK_ID;
}

const JITO_ENDPOINTS = [
    'https://mainnet.block-engine.jito.wtf/api/v1/bundles',
    'https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/bundles',
    'https://frankfurt.mainnet.block-engine.jito.wtf/api/v1/bundles',
    'https://ny.mainnet.block-engine.jito.wtf/api/v1/bundles',
    'https://tokyo.mainnet.block-engine.jito.wtf/api/v1/bundles',
    'https://slc.mainnet.block-engine.jito.wtf'
];

const JITO_TIP_ACCOUNTS = [
    'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
    'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
    '96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5',
    '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT',
    'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe',
    'ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49',
    'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt',
    'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh'
]

const JUPITER_API_BASE_URL = {
    QUOTE: 'https://api.jup.ag/swap/v1/quote/',
    SWAP: 'https://api.jup.ag/swap/v1/swap/',
}

module.exports = {
    setWebHookID, 
    getWebHookID,
    JITO_ENDPOINTS,
    JITO_TIP_ACCOUNTS,
    JUPITER_API_BASE_URL
};
